#include <stdio.h>
intmain (){
  double a, x, b;
  printf ("inserisci a");
  scanf ("%lf", &a);
  printf ("inserisci b");
  scanf ("%lf", &b);
  x = (-b / a);
  printf ("X = %.2f", x);
  return 0;
}