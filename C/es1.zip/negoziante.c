#include <stdio.h>
int main(){
	double lun,mar,mer,gio,ven,sab,dom,tot;
	printf("inserisci il guadagno di lunedi: ");
	scanf("%lf", &lun);
	printf("inserisci il guadagno di martedi: ");
	scanf("%lf", &mar);
	printf("inserisci il guadagno di mercoledi: ");
	scanf("%lf", &mer);
	printf("inserisci il guadagno di giovedi: ");
	scanf("%lf", &gio);
	printf("inserisci il guadagno di venerdi: ");
	scanf("%lf", &ven);
	printf("inserisci il guadagno di sabato: ");
	scanf("%lf", &sab);
	printf("inserisci il guadagno di domenica: ");
	scanf("%lf", &dom);
	
	tot = lun+mar+mer+gio+ven+sab+dom;
	printf("il totale e': %f ", tot);
	
	return 0;
}
