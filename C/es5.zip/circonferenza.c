#include <stdio.h>
int main (){
  float raggio;
  printf ("inserisci un numero: ");
  scanf ("%f", &raggio);
  float circonferenza = (raggio*raggio)*3.14;
  printf("la circonferenza vale: %f", circonferenza);
  return 0;
}
